package br.com.caelum.hibernate.modelo;

public enum Tipo {
	SAIDA, ENTRADA;

}
